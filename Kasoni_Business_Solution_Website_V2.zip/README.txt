KASONI BUSINESS SOLUTION LIMITED WEBSITE – VERSION 2
The website includes the supplied Kasoni logo and a Founder section for CPA(T) Evarist Kasoni.
Founder qualification: Master of Science in Accounting and Finance, Tanzania Institute of Accountancy (TIA).
Main file: index.html
Logo file: kasoni-logo.jpeg
Upload both files to the same web hosting folder.
